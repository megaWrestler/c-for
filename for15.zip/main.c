#include <stdio.h>
#include <math.h>
#include <gmp.h>
int main() {
    long long a = 1;

    for (char b = 'z'; b >= 'a'; b--) { 
       a *= (int)b;
    

   
}
printf("ASCII qiymatlari ko'paytmasi: %lld\n", a);
 return 0;
} 

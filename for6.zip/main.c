/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int bir=0,on=0,yuz=0;
   
    for(int i=100;i<=999;i++){
    yuz=i/100;
    on=i/10%10;
    bir=i%10;
    
    if(bir*on*yuz<16){
        printf( "%d\n",i);
    }
    
}

    return 0;
}

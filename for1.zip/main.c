/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
  int plus,minus,res=0;
  printf("Manfiy son kiriting");//-1
  scanf("%d",&minus);
  printf("Musbat son kiriting");//9
  scanf("%d",&plus);
  
  for(int i=minus;minus<=plus;i++){
      res+=i; //res=res+(-1)
      
      minus++;
      
  }
  
  printf("%d",res);
  
  
  

    return 0;
}
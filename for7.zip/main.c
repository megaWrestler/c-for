/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int bir,on,yuz,ming, count=0;
    
    for(int i=1000;i<=9999;i++){
    ming=i/1000;
    yuz=i/100%10;
    on=i/10%10;
    bir=i%10;
    if(on+bir+yuz+ming>10&&on+bir+yuz+ming<15&&count<5){
        printf( "%d\n",i);
        count++;
    }
    }
    
    
    
    
    return 0;
}

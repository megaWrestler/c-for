/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int n,m;
    printf("1-sonni kiriting :");
    scanf("%d",&n);
    printf("2-sonni kiriting :");
    scanf("%d",&m);
    
    if(n>m){
        for(int i=m;i<=n;i+=3){
            printf("%d\n",i);
        }
    }else{
            for(int i=n;m>=i;i+=3){
            printf("%d\n",i);
        }
        
    }
    
    
    
    return 0;
}
